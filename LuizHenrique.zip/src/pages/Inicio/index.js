

export default function Inicio(){

    return(
        <div>
            <h1>Início</h1>
        </div>
    )
}