

export default function Filmes(){
    return(
        <div>
            <h1> Filmes Populares</h1>
       </div>
    )
}