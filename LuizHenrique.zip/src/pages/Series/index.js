

export default function Series(){
    return(
        <div>
            <h1>Séries</h1>
        </div>
    )
}