export default function Cartaz(){
    return(
        <div>
           <h1>Cartaz</h1>
        </div>
    )
}