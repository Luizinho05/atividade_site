function SerieP(){
    return(
        <div>
            <h1>Séries Populares</h1>
        </div>
    )
}

export default SerieP;