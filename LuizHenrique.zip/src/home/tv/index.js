

export default function Natv(){
    return(
        <div>
            <h1>Na TV</h1>
        </div>
    )
}