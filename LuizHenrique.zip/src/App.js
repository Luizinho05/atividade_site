import Rotas from './routes'

function App() {
  return (
    <div>
      <Rotas />
    </div>
  );
}

export default App;
